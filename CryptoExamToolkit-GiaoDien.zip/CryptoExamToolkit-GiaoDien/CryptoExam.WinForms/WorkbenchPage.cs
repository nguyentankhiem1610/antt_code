using System.Text;

namespace CryptoExam.WinForms;

// Shared layout: inputs, action buttons, result, and a separate walkthrough.
internal sealed class WorkbenchPage : TabPage
{
    public ComboBox Method { get; } = new() { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
    public TextBox Input { get; } = Box(false);
    public TextBox Result { get; } = Box(true);
    public TextBox Details { get; } = Box(true);
    public Label Hint { get; } = new() { Dock = DockStyle.Fill, AutoSize = true, ForeColor = Color.FromArgb(62, 84, 111) };
    private readonly Dictionary<string, TextBox> fields = new();
    private readonly Dictionary<string, Label> labels = new();
    private readonly FlowLayoutPanel actions = new() { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
    private readonly Label status = new() { Text = "Sẵn sàng", Dock = DockStyle.Fill, AutoSize = true };
    private readonly TableLayoutPanel parameters = new() { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2 };

    public WorkbenchPage(string title, params string[] fieldNames)
    {
        Text = title; BackColor = Color.White; Padding = new Padding(14);
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 8 };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 24));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 76));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.Controls.Add(Method, 0, 0); root.Controls.Add(Hint, 0, 1);
        parameters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
        parameters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        foreach (var name in fieldNames)
        {
            var index = fields.Count;
            var label = new Label { Text = name, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(3, 8, 3, 8) };
            var box = new TextBox { Dock = DockStyle.Fill, Margin = new Padding(3, 5, 3, 5) };
            fields.Add(name, box); labels.Add(name, label);
            parameters.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            parameters.Controls.Add(label, 0, index); parameters.Controls.Add(box, 1, index);
        }
        root.Controls.Add(parameters, 0, 2);
        root.Controls.Add(new Label { Text = "DỮ LIỆU ĐẦU VÀO", AutoSize = true }, 0, 3);
        root.Controls.Add(Input, 0, 4); root.Controls.Add(actions, 0, 5);
        var output = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4 };
        output.RowStyles.Add(new RowStyle(SizeType.Absolute, 25));
        output.RowStyles.Add(new RowStyle(SizeType.Percent, 25));
        output.RowStyles.Add(new RowStyle(SizeType.Absolute, 25));
        output.RowStyles.Add(new RowStyle(SizeType.Percent, 75));
        output.Controls.Add(new Label { Text = "KẾT QUẢ", AutoSize = true }, 0, 0);
        output.Controls.Add(Result, 0, 1);
        output.Controls.Add(new Label { Text = "THÔNG SỐ VÀ CÁC BƯỚC TÍNH", AutoSize = true }, 0, 2);
        output.Controls.Add(Details, 0, 3);
        root.Controls.Add(output, 0, 6); root.Controls.Add(status, 0, 7); Controls.Add(root);
    }

    private static TextBox Box(bool readOnly) => new()
    {
        Multiline = true, ReadOnly = readOnly, Dock = DockStyle.Fill,
        ScrollBars = ScrollBars.Both, WordWrap = false, MaxLength = 0,
        Font = new Font("Consolas", 11), BackColor = readOnly ? Color.FromArgb(244, 247, 251) : Color.White
    };
    public string Value(string name) => fields[name].Text.Trim();
    public void Set(string name, string value) => fields[name].Text = value;
    public void Field(string name, string caption, bool enabled = true)
    {
        labels[name].Text = caption; fields[name].Enabled = enabled;
    }
    public void ShowResult(string result, string details)
    {
        Result.Text = result; Details.Text = details; status.Text = "Đã tính xong"; status.ForeColor = Color.DarkGreen;
    }
    public void ClearOutput() { Result.Clear(); Details.Clear(); status.Text = "Sẵn sàng"; }
    public void Button(string text, Action action)
    {
        var button = new Button { Text = text, AutoSize = true, Padding = new Padding(8, 4, 8, 4), Margin = new Padding(0, 6, 8, 6) };
        button.Click += (_, _) =>
        {
            try { action(); }
            catch (Exception ex)
            {
                ClearOutput(); status.Text = "Vui lòng kiểm tra dữ liệu"; status.ForeColor = Color.Firebrick;
                MessageBox.Show(this, ex.Message, "Dữ liệu không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        };
        actions.Controls.Add(button);
    }
    public void CommonButtons()
    {
        Button("Kết quả → Đầu vào", () => { if (Result.Text.Length > 0) Input.Text = Result.Text; });
        Button("Sao chép", () => { if (Result.Text.Length > 0) Clipboard.SetText(Result.Text); });
        Button("Lưu lời giải", () =>
        {
            if (Result.Text.Length == 0) throw new ArgumentException("Chưa có kết quả để lưu.");
            using var dialog = new SaveFileDialog { Filter = "Văn bản UTF-8 (*.txt)|*.txt", FileName = "LoiGiai.txt" };
            if (dialog.ShowDialog(this) == DialogResult.OK)
            {
                string parametersText = string.Join(Environment.NewLine, fields.Where(x => x.Value.Enabled).Select(x => $"{labels[x.Key].Text}: {x.Value.Text}"));
                File.WriteAllText(dialog.FileName, $"{Text} / {Method.Text}\r\n{parametersText}\r\nĐầu vào: {Input.Text}\r\nKết quả: {Result.Text}\r\n\r\n{Details.Text}", Encoding.UTF8);
            }
        });
        Button("Xóa", () => { Input.Clear(); ClearOutput(); });
    }
}
