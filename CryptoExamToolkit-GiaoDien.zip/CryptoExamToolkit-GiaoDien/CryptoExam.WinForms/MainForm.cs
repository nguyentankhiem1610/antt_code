using System.Numerics;
using System.Text;
using CryptoExam.Core.Classical;
using CryptoExam.Core.Common;
using CryptoExam.Core.DES;
using CryptoExam.Core.AES;
using CryptoExam.Core.RSA;
using CryptoExam.Core.NumberTheory;
using CryptoExam.Core.SelfTest;

namespace CryptoExam.WinForms;

public sealed class MainForm : Form
{
    private const string Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public MainForm()
    {
        Text = "CryptoExam • Bộ công cụ thực hành An ninh thông tin";
        Font = new Font("Segoe UI", 10);
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1180, 860); MinimumSize = new Size(960, 760);
        AutoScaleMode = AutoScaleMode.Dpi;
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 65)); root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(new Label
        {
            Text = "CRYPTO EXAM  /  Nhập dữ liệu → Chọn thao tác → Xem lời giải",
            Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(18, 0, 0, 0),
            BackColor = Color.FromArgb(24, 45, 76), ForeColor = Color.White, Font = new Font("Segoe UI", 15, FontStyle.Bold)
        }, 0, 0);
        var tabs = new TabControl { Dock = DockStyle.Fill };
        tabs.TabPages.Add(ClassicalPage()); tabs.TabPages.Add(DesPage()); tabs.TabPages.Add(AesPage());
        tabs.TabPages.Add(RsaPage()); tabs.TabPages.Add(CalculatorPage()); tabs.TabPages.Add(CheckPage());
        root.Controls.Add(tabs, 0, 1); Controls.Add(root);
    }
    private static BigInteger Number(string value, string name)
    {
        if (value.Length > 5000) throw new ArgumentException($"{name} quá dài (tối đa 5000 ký tự).");
        if (!BigInteger.TryParse(value, out var result)) throw new ArgumentException($"{name} phải là số nguyên.");
        return result;
    }
    private static int Integer(string value, string name)
    {
        if (!int.TryParse(value, out var result)) throw new ArgumentException($"{name} phải là số nguyên 32 bit.");
        return result;
    }
    private static void RequireInput(WorkbenchPage page)
    {
        if (string.IsNullOrWhiteSpace(page.Input.Text)) throw new ArgumentException("Vui lòng nhập dữ liệu đầu vào.");
        if (page.Input.Text.Length > 10000) throw new ArgumentException("Mỗi lần thao tác tối đa 10000 ký tự.");
    }

    private static WorkbenchPage ClassicalPage()
    {
        var p = new WorkbenchPage("Mã cổ điển", "Khóa", "Khóa 2");
        p.Method.Items.AddRange(new object[] { "Caesar", "Thay thế đơn", "Vigenère", "Playfair", "One-Time Pad", "Rail Fence", "Hoán vị cột", "Hoán vị kép", "Hoán vị ma trận" });
        void Sample()
        {
            p.ClearOutput(); p.Input.Text = "ATTACKATDAWN"; p.Set("Khóa 2", "ZEBRAS");
            var keys = new[] { "3", "QWERTYUIOPASDFGHJKLZXCVBNM", "LEMON", "MONARCHY", "XMCKLQWERTYU", "3", "MONARCH", "MONARCH", "4" };
            p.Set("Khóa", keys[p.Method.SelectedIndex]);
            if (p.Method.SelectedIndex == 4) { p.Input.Text = "DATA"; p.Set("Khóa", "XMCK"); }
        }
        p.Method.SelectedIndexChanged += (_, _) =>
        {
            int m = p.Method.SelectedIndex;
            p.Field("Khóa", m == 1 ? "Bảng thay thế (26 chữ)" : m == 5 ? "Số hàng (≥ 2)" : m == 8 ? "Số cột (≥ 2)" : "Khóa");
            p.Field("Khóa 2", "Khóa thứ hai", m == 7);
            p.Hint.Text = m == 4 ? "OTP: khóa có cùng số chữ A–Z với bản tin, không lặp khóa." : m == 3 ? "Playfair: gộp J vào I, chèn X/Q; giải mã giữ ký tự đệm." : m is 5 or 6 or 7 or 8 ? "Hoán vị: nhập bản tin và số hàng/cột hoặc từ khóa." : "Mã chữ dùng A–Z không dấu. A=0 … Z=25; khoảng trắng được giữ với Caesar, Vigenère và thay thế đơn.";
            Sample();
        };
        void Run(bool decrypt)
        {
            RequireInput(p); string t = p.Input.Text, k = p.Value("Khóa"), k2 = p.Value("Khóa 2");
            var details = new StringBuilder(); string result;
            details.AppendLine(decrypt ? "THAO TÁC: GIẢI MÃ" : "THAO TÁC: MÃ HÓA"); details.AppendLine($"Khóa: {k}");
            switch (p.Method.SelectedIndex)
            {
                case 0:
                    int shift = Integer(k, "Khóa"); shift = TextUtils.Mod(shift, 26);
                    result = decrypt ? CaesarCipher.Decrypt(t, shift) : CaesarCipher.Encrypt(t, shift);
                    details.AppendLine($"k mod 26 = {shift}; y = (x {(decrypt ? "-" : "+")} k) mod 26");
                    foreach (char c in TextUtils.LettersOnly(t)) { int x = c - 'A', y = TextUtils.Mod(x + (decrypt ? -shift : shift), 26); details.AppendLine($"{c}({x}) → {Alphabet[y]}({y})"); }
                    break;
                case 1:
                    var mono = new MonoalphabeticCipher(Alphabet, k);
                    result = decrypt ? mono.Decrypt(t) : mono.Encrypt(t);
                    details.AppendLine(Alphabet); details.AppendLine(mono.CipherAlphabet); break;
                case 2:
                    result = decrypt ? VigenereCipher.Decrypt(t, k) : VigenereCipher.Encrypt(t, k);
                    var expanded = VigenereCipher.ExpandKey(t, k); details.AppendLine($"Khóa mở rộng: {expanded}");
                    details.AppendLine($"y_i = (x_i {(decrypt ? "-" : "+")} k_i) mod 26");
                    var letters = TextUtils.LettersOnly(t);
                    for (int i = 0; i < letters.Length; i++) { int x = letters[i] - 'A', a = expanded[i] - 'A', y = TextUtils.Mod(x + (decrypt ? -a : a), 26); details.AppendLine($"{letters[i]}({x}), {expanded[i]}({a}) → {Alphabet[y]}({y})"); }
                    break;
                case 3:
                    var play = new PlayfairCipher(k); details.AppendLine("Ma trận 5×5:"); details.AppendLine(play.MatrixText);
                    result = decrypt ? play.Decrypt(t) : play.Encrypt(t);
                    var pairs = decrypt ? Enumerable.Range(0, TextUtils.LettersOnly(t, true).Length / 2).Select(i => TextUtils.LettersOnly(t, true).Substring(i * 2, 2)) : play.PreparePairs(t);
                    details.AppendLine("Cùng hàng: dịch cột; cùng cột: dịch hàng; khác hàng/cột: đổi cột.");
                    foreach (string pair in pairs) details.AppendLine($"{pair} → {(decrypt ? play.DecryptPair(pair) : play.EncryptPair(pair))}");
                    break;
                case 4:
                    result = decrypt ? OneTimePadCipher.Decrypt(t, k) : OneTimePadCipher.Encrypt(t, k);
                    details.AppendLine($"y_i = (x_i {(decrypt ? "-" : "+")} k_i) mod 26; không lặp khóa."); break;
                case 5:
                    int rails = Integer(k, "Số hàng"); if (rails > 1000) throw new ArgumentException("Tối đa 1000 hàng.");
                    result = decrypt ? RailFenceCipher.Decrypt(t, rails) : RailFenceCipher.Encrypt(t, rails);
                    details.AppendLine($"Số hàng: {rails}; ghi zigzag, đọc lần lượt từng hàng."); break;
                case 6:
                    var column = new ColumnarTranspositionCipher(k); result = decrypt ? column.Decrypt(t) : column.Encrypt(t);
                    details.AppendLine("Ma trận bản rõ:"); details.AppendLine(column.Matrix(decrypt ? result : t)); break;
                case 7:
                    result = decrypt ? DoubleTranspositionCipher.Decrypt(t, k, k2) : DoubleTranspositionCipher.Encrypt(t, k, k2);
                    details.AppendLine($"Khóa 2: {k2}");
                    details.AppendLine($"Bước 1: {(decrypt ? new ColumnarTranspositionCipher(k2).Decrypt(t) : new ColumnarTranspositionCipher(k).Encrypt(t))}");
                    details.AppendLine("Giải mã thực hiện khóa 2 trước, khóa 1 sau."); break;
                default:
                    int columns = Integer(k, "Số cột"); if (columns < 2 || columns > 1000) throw new ArgumentException("Số cột từ 2 đến 1000.");
                    result = decrypt ? MatrixTranspositionCipher.Decrypt(t, columns) : MatrixTranspositionCipher.Encrypt(t, columns);
                    details.AppendLine(MatrixTranspositionCipher.Matrix(decrypt ? result : t, columns)); break;
            }
            details.AppendLine($"Kết quả: {result}"); p.ShowResult(result, details.ToString());
        }
        p.Button("Mã hóa", () => Run(false)); p.Button("Giải mã", () => Run(true)); p.Button("Dữ liệu mẫu", Sample);
        p.Button("Dò khóa Caesar", () => { RequireInput(p); var lines = CaesarCipher.BruteForce(p.Input.Text).Select(x => $"k={x.Key}: {x.Value}"); p.ShowResult(string.Join(Environment.NewLine, lines), "Thử toàn bộ 26 khóa Caesar."); });
        p.Button("Tạo bảng thay thế", () => { var generated = EncodingUtils.GenerateMonoAlphabet(p.Value("Khóa")); p.Set("Khóa", generated.FinalAlphabet); p.ShowResult(generated.FinalAlphabet, $"Chuẩn hóa: {generated.NormalizedSeed}\r\nBỏ trùng: {generated.UniqueSeed}"); });
        p.CommonButtons(); p.Method.SelectedIndex = 0; return p;
    }

    private static WorkbenchPage DesPage()
    {
        var p = new WorkbenchPage("DES / Triple DES", "K1", "K2", "K3");
        p.Method.Items.AddRange(new object[] { "DES", "Double DES", "Triple DES EDE (2 khóa)", "Triple DES EDE (3 khóa)", "Triple DES EEE" });
        p.Hint.Text = "Một khối 64 bit: đầu vào 16 ký tự hex, mỗi khóa 16 ký tự hex. DES hiển thị đủ 16 vòng và S-box.";
        void Sample() { p.ClearOutput(); p.Input.Text = "0123456789ABCDEF"; p.Set("K1", "133457799BBCDFF1"); p.Set("K2", "0E329232EA6D0D73"); p.Set("K3", "AABB09182736CCDD"); }
        p.Method.SelectedIndexChanged += (_, _) => { p.Field("K2", "Khóa K2 (hex)", p.Method.SelectedIndex > 0); p.Field("K3", "Khóa K3 (hex)", p.Method.SelectedIndex >= 3); p.ClearOutput(); };
        void Run(bool decrypt)
        {
            RequireInput(p); string t = p.Input.Text, k = p.Value("K1"), k2 = p.Value("K2"), k3 = p.Value("K3");
            if (p.Method.SelectedIndex == 0)
            {
                var trace = DesCipher.Trace(t, k, decrypt); var d = new StringBuilder();
                d.AppendLine($"IP = {trace.InitialPermutationHex}\r\nL0 = {trace.L0Hex}\r\nR0 = {trace.R0Hex}");
                d.AppendLine($"PC1 = {trace.KeySchedule.Pc1Hex}; C0 = {trace.KeySchedule.C0Hex}; D0 = {trace.KeySchedule.D0Hex}");
                d.AppendLine("SINH KHÓA (thứ tự K1…K16):");
                foreach (var r in trace.KeySchedule.Rounds) d.AppendLine($"Vòng {r.Round}: dịch {r.Shift}; C={r.CHex}; D={r.DHex}; CD={r.CDHex}; K={r.SubKeyHex}");
                d.AppendLine(decrypt ? "GIẢI MÃ: dùng khóa K16…K1." : "MÃ HÓA: dùng khóa K1…K16.");
                foreach (var r in trace.Rounds)
                {
                    d.AppendLine($"\r\nVòng {r.Round}: E(R)={r.Function.ExpandedRHex}; K={r.Function.SubKeyHex}; XOR={r.Function.XorHex}");
                    foreach (var s in r.Function.SBoxes) d.AppendLine($"S{s.SBoxNumber}: {s.InputBinary}; hàng={s.Row}, cột={s.Column} → {s.Value} ({s.OutputBinary})");
                    d.AppendLine($"S-box={r.Function.SBoxHex}; P={r.Function.PHex}; L={r.LHex}; R={r.RHex}");
                }
                d.AppendLine($"\r\nR16L16={trace.PreOutputHex}; IP⁻¹ → {trace.OutputHex}"); p.ShowResult(trace.OutputHex, d.ToString());
            }
            else
            {
                MultiDesResult r = p.Method.SelectedIndex switch
                {
                    1 => decrypt ? TripleDesService.DoubleDecrypt(t, k, k2) : TripleDesService.DoubleEncrypt(t, k, k2),
                    2 => decrypt ? TripleDesService.DecryptEde(t, k, k2) : TripleDesService.EncryptEde(t, k, k2),
                    3 => decrypt ? TripleDesService.DecryptEde(t, k, k2, k3) : TripleDesService.EncryptEde(t, k, k2, k3),
                    _ => decrypt ? DecryptEee(t, k, k2, k3) : TripleDesService.EncryptEee(t, k, k2, k3)
                };
                p.ShowResult(r.FinalCiphertext, $"{p.Method.Text} / {(decrypt ? "Giải mã" : "Mã hóa")}\r\nBước 1: {r.Step1}\r\nBước 2: {r.Step2}\r\nBước 3: {r.Step3}\r\nKết quả: {r.FinalCiphertext}");
            }
        }
        p.Button("Mã hóa", () => Run(false)); p.Button("Giải mã", () => Run(true)); p.Button("Dữ liệu mẫu", Sample); p.CommonButtons();
        p.Method.SelectedIndex = 0; Sample(); return p;
    }
    private static MultiDesResult DecryptEee(string input, string k1, string k2, string k3)
    {
        string a = DesCipher.Decrypt(input, k3), b = DesCipher.Decrypt(a, k2), c = DesCipher.Decrypt(b, k1); return new(a, b, c, c);
    }

    private static WorkbenchPage AesPage()
    {
        var p = new WorkbenchPage("AES", "Khóa");
        p.Method.Items.AddRange(new object[] { "AES-128", "AES-192", "AES-256" });
        p.Hint.Text = "Đầu vào một khối 128 bit (32 ký tự hex). Khóa: 32/48/64 ký tự hex. Các bước trung gian có ở mã hóa AES-128.";
        void Sample() { p.ClearOutput(); p.Input.Text = "00112233445566778899AABBCCDDEEFF"; p.Set("Khóa", "000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F"[..(32 + 16 * p.Method.SelectedIndex)]); }
        p.Method.SelectedIndexChanged += (_, _) => Sample();
        void Run(bool decrypt)
        {
            RequireInput(p); string key = HexUtils.Normalize(p.Value("Khóa"), 32 + 16 * p.Method.SelectedIndex);
            string result = decrypt ? AesService.QuickDecrypt(p.Input.Text, key) : AesService.QuickEncrypt(p.Input.Text, key);
            var d = new StringBuilder($"{p.Method.Text}\r\nKhóa = {key}\r\nSố vòng = {10 + 2 * p.Method.SelectedIndex}\r\n");
            if (!decrypt && p.Method.SelectedIndex == 0)
                foreach (var r in AesService.TraceEncrypt128(p.Input.Text, key).Rounds)
                    d.AppendLine($"Vòng {r.Round}\r\nRoundKey: {r.RoundKeyHex}\r\nSubBytes: {r.SubBytesHex}\r\nShiftRows: {r.ShiftRowsHex}\r\nMixColumns: {r.MixColumnsHex}\r\nAddRoundKey: {r.AddRoundKeyHex}\r\n");
            else d.AppendLine("Chế độ này trả kết quả; Core chưa cung cấp dấu vết các vòng cho giải mã hoặc AES-192/256.");
            p.ShowResult(result, d.ToString());
        }
        p.Button("Mã hóa", () => Run(false)); p.Button("Giải mã", () => Run(true)); p.Button("Dữ liệu mẫu", Sample); p.CommonButtons(); p.Method.SelectedIndex = 0; return p;
    }

    private static WorkbenchPage RsaPage()
    {
        var p = new WorkbenchPage("RSA", "p", "q", "e");
        p.Method.Items.AddRange(new object[] { "RSA chuẩn (công khai e, bí mật d)", "RSA theo slide UEH (bí mật eA, công khai dA)" });
        p.Method.SelectedIndex = 0;
        p.Hint.Text = "Nhập p, q nguyên tố khác nhau, e nguyên tố cùng nhau với φ(n). Đầu vào: số hoặc danh sách số, cách bằng dấu phẩy/khoảng trắng; 0 ≤ mỗi số < n.";
        void Sample() { p.ClearOutput(); p.Set("p", "13"); p.Set("q", "17"); p.Set("e", "7"); p.Input.Text = "64 112 97"; }
        RsaKeyPair Keys()
        {
            var a = Number(p.Value("p"), "p"); var b = Number(p.Value("q"), "q");
            if (a > 1000000000 || b > 1000000000) throw new ArgumentException("Giao diện bài tập hỗ trợ p, q ≤ 10^9 để kiểm tra nguyên tố nhanh.");
            if (a == b || !PrimeUtils.IsPrime(a) || !PrimeUtils.IsPrime(b))
                throw new ArgumentException("p, q phải là hai số nguyên tố khác nhau.");
            var e = Number(p.Value("e"), "e");
            var phi = (a - 1) * (b - 1);
            if (e <= 1 || e >= phi) throw new ArgumentException("e phải thỏa 1 < e < φ(n).");
            return RsaService.CalculateKeys(a, b, e);
        }
        string KeyDetails(RsaKeyPair k) => $"n = p×q = {k.P}×{k.Q} = {k.N}\r\nφ(n) = (p−1)(q−1) = {k.Phi}\r\ngcd(e,φ) = {k.Gcd}\r\nd = e⁻¹ mod φ = {k.D}\r\ne×d mod φ = {k.E * k.D % k.Phi}\r\n" +
            (p.Method.SelectedIndex == 0 ? $"Công khai: ({k.E}, {k.N}); bí mật: ({k.D}, {k.N})\r\n" : $"Bí mật eA={k.E}; công khai dA={k.D}; n={k.N}\r\n");
        void Run(int action)
        {
            RequireInput(p); var keys = Keys(); bool ueh = p.Method.SelectedIndex == 1;
            BigInteger exponent = action switch { 0 => ueh ? keys.D : keys.E, 1 => ueh ? keys.E : keys.D, 2 => ueh ? keys.E : keys.D, _ => ueh ? keys.D : keys.E };
            var values = p.Input.Text.Split(new[] { ',', ';', ' ', '\r', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries).Select(x => Number(x, "Đầu vào")).ToArray();
            var outputs = new List<BigInteger>(); var d = new StringBuilder(KeyDetails(keys));
            d.AppendLine(new[] { "Mã hóa", "Giải mã", "Ký", "Khôi phục từ chữ ký" }[action]);
            foreach (var x in values)
            {
                var y = RsaService.Encrypt(x, exponent, keys.N); outputs.Add(y); d.AppendLine($"{x}^{exponent} mod {keys.N} = {y}");
                foreach (var s in ModularArithmetic.TraceModPow(x, exponent, keys.N)) d.AppendLine($"  Bước {s.Step}: số mũ={s.Exponent}; nhân={s.Multiply}; kết quả={s.ResultAfter}; cơ số mới={s.BaseAfter}");
            }
            if (action == 3) d.AppendLine("Đối chiếu số khôi phục với bản tin gốc để xác thực chữ ký.");
            p.ShowResult(string.Join(" ", outputs), d.ToString());
        }
        p.Button("Tính khóa n, φ, d", () => { var k = Keys(); p.ShowResult($"n={k.N}; φ={k.Phi}; d={k.D}", KeyDetails(k)); });
        p.Button("Mã hóa", () => Run(0)); p.Button("Giải mã", () => Run(1)); p.Button("Ký", () => Run(2)); p.Button("Khôi phục chữ ký", () => Run(3));
        p.Button("Dữ liệu mẫu", Sample); p.CommonButtons(); p.Method.SelectedIndexChanged += (_, _) => p.ClearOutput(); Sample(); return p;
    }

    private static WorkbenchPage CalculatorPage()
    {
        var p = new WorkbenchPage("Máy tính / Tiện ích", "a", "b", "m");
        var methods = new object[] { "Cộng", "Trừ", "Nhân", "Chia nguyên và dư", "a mod m", "a×b mod m", "a^b mod m", "UCLN / Euclid mở rộng", "Nghịch đảo a mod m", "Kiểm tra nguyên tố", "Đổi cơ số", "Văn bản → A0Z25", "A0Z25 → Văn bản", "Văn bản → ASCII", "ASCII → Văn bản", "Hex → Nhị phân", "Nhị phân → Hex", "Khóa Caesar từ ngày/tháng", "Số hàng Rail Fence từ ngày" };
        p.Method.Items.AddRange(methods);
        void Sample()
        {
            p.ClearOutput(); p.Set("a", "550"); p.Set("b", "1759"); p.Set("m", "1759"); p.Input.Text = "HELLO";
            if (p.Method.SelectedIndex == 6) { p.Set("a", "64"); p.Set("b", "7"); p.Set("m", "221"); }
            if (p.Method.SelectedIndex == 10) { p.Input.Text = "FF"; p.Set("a", "16"); p.Set("b", "2"); }
            if (p.Method.SelectedIndex == 12) p.Input.Text = "7 4 11 11 14";
            if (p.Method.SelectedIndex == 14) p.Input.Text = "72 69 76 76 79";
            if (p.Method.SelectedIndex == 15) p.Input.Text = "FF";
            if (p.Method.SelectedIndex == 16) p.Input.Text = "11111111";
            if (p.Method.SelectedIndex >= 17) { p.Set("a", "15"); p.Set("b", "10"); }
        }
        p.Method.SelectedIndexChanged += (_, _) =>
        {
            int i = p.Method.SelectedIndex;
            p.Field("a", i == 10 ? "Cơ số nguồn (2…16)" : i >= 17 ? "Ngày" : "a", i <= 10 || i >= 17);
            p.Field("b", i == 10 ? "Cơ số đích (2…16)" : i == 17 ? "Tháng" : "b", i <= 3 || i is 5 or 6 or 7 or 10 or 17);
            p.Field("m", "Modulo m (> 0)", i is 4 or 5 or 6 or 8);
            p.Hint.Text = i >= 10 && i <= 16 ? "Nhập chuỗi vào vùng Đầu vào. Đổi cơ số sử dụng a là cơ số nguồn, b là cơ số đích." : "Nhập số nguyên vào a, b, m tương ứng. Chia trả thương nguyên và số dư; lũy thừa modulo có các bước bình phương–nhân.";
            Sample();
        };
        void Run()
        {
            int i = p.Method.SelectedIndex; string result, detail;
            if (i >= 10 && i <= 16)
            {
                RequireInput(p); string t = p.Input.Text;
                result = i switch
                {
                    10 => NumberBaseConverter.Format(NumberBaseConverter.Parse(t, Integer(p.Value("a"), "Cơ số nguồn")), Integer(p.Value("b"), "Cơ số đích")),
                    11 => string.Join(" ", EncodingUtils.TextToA0Z25(t)),
                    12 => EncodingUtils.A0Z25ToText(EncodingUtils.ParseIntList(t)),
                    13 => string.Join(" ", EncodingUtils.TextToAsciiList(t)),
                    14 => EncodingUtils.AsciiListToText(EncodingUtils.ParseIntList(t)),
                    15 => HexUtils.HexToBinary(t),
                    _ => HexUtils.BinaryToHex(t)
                };
                detail = $"{p.Method.Text}\r\n{t} → {result}";
            }
            else
            {
                BigInteger a = Number(p.Value("a"), "a"), b = 0, m = 1;
                if (i <= 3 || i is 5 or 6 or 7 or 17) b = Number(p.Value("b"), "b");
                if (i is 4 or 5 or 6 or 8) { m = Number(p.Value("m"), "m"); if (m <= 0) throw new ArgumentException("m phải > 0."); }
                detail = p.Method.Text;
                switch (i)
                {
                    case 0: result = (a + b).ToString(); break;
                    case 1: result = (a - b).ToString(); break;
                    case 2: result = (a * b).ToString(); break;
                    case 3: if (b == 0) throw new ArgumentException("Không thể chia cho 0."); result = $"Thương = {a / b}; dư = {a % b}"; detail = $"{a} = ({a / b})×({b}) + ({a % b})"; break;
                    case 4: result = ModularArithmetic.Normalize(a, m).ToString(); break;
                    case 5: result = ModularArithmetic.Normalize(a * b, m).ToString(); break;
                    case 6:
                        result = ModularArithmetic.ModPow(a, b, m).ToString();
                        detail = $"{a}^{b} mod {m}\r\n" + string.Join(Environment.NewLine, ModularArithmetic.TraceModPow(a, b, m).Select(s => $"Bước {s.Step}: số mũ={s.Exponent}; nhân={s.Multiply}; kết quả={s.ResultAfter}; cơ số mới={s.BaseAfter}")); break;
                    case 7:
                        var euclid = ExtendedEuclidService.Solve(a, b); result = euclid.Gcd.ToString();
                        detail = $"x={euclid.X}; y={euclid.Y}; a×x+b×y={euclid.Gcd}\r\n" + string.Join(Environment.NewLine, euclid.Steps.Select(s => $"{s.Dividend} = {s.Quotient}×{s.Divisor} + {s.Remainder}")); break;
                    case 8:
                        result = ExtendedEuclidService.ModularInverse(a, m).ToString();
                        var inverse = ExtendedEuclidService.Solve(a, m);
                        detail = string.Join(Environment.NewLine, inverse.Steps.Select(s => $"{s.Dividend} = {s.Quotient}×{s.Divisor} + {s.Remainder}")) + $"\r\nx={inverse.X}, y={inverse.Y}; a×x+m×y=1\r\nKiểm tra: a×nghịch đảo mod m = {ModularArithmetic.Normalize(a * BigInteger.Parse(result), m)}"; break;
                    case 9: if (a > 1000000000) throw new ArgumentException("Kiểm tra nguyên tố trong giao diện giới hạn 10^9."); result = PrimeUtils.IsPrime(a) ? "Là số nguyên tố" : "Không phải số nguyên tố"; break;
                    case 17: var caesar = ExamFormulaService.CaesarKeyFromDate(Integer(p.Value("a"), "Ngày"), Integer(p.Value("b"), "Tháng")); result = caesar.K.ToString(); detail = caesar.Formula; break;
                    default: var rail = ExamFormulaService.RailFenceFromDay(Integer(p.Value("a"), "Ngày")); result = rail.Rails.ToString(); detail = rail.Formula; break;
                }
                if (i <= 2 || i is 4 or 5) detail += $"\r\na={a}; b={b}; m={m}\r\nKết quả={result}";
            }
            p.ShowResult(result, detail);
        }
        p.Button("Tính / Chuyển đổi", Run); p.Button("Dữ liệu mẫu", Sample); p.CommonButtons(); p.Method.SelectedIndex = 6; return p;
    }
    private static WorkbenchPage CheckPage()
    {
        var p = new WorkbenchPage("Tự kiểm tra / Hướng dẫn"); p.Method.Items.Add("Bộ kiểm tra thuật toán có sẵn"); p.Method.SelectedIndex = 0;
        p.Hint.Text = "Kiểm tra thuật toán Core bằng các vectơ mẫu. Mã nguồn giao diện nằm trong CryptoExam.WinForms.";
        p.Input.Text = "1. Chọn tab và phương pháp.\r\n2. Nhập bản tin, khóa hoặc các số cần tính.\r\n3. Nhấn Mã hóa / Giải mã / Tính.\r\n4. Xem lời giải bên dưới, Sao chép hoặc Lưu lời giải.\r\n5. Dùng Kết quả → Đầu vào để giải mã lại.\r\n\r\nMã cổ điển dùng chữ A–Z không dấu. DES/AES xử lý khối hex.\r\nRSA dùng số hoặc danh sách số.\r\nCác menu Console chuyên sâu vẫn có trong CryptoExam.Console."; p.Input.ReadOnly = true;
        p.Button("Chạy tự kiểm tra", () => { var tests = SelfTestRunner.RunAll(); p.ShowResult($"Đạt {tests.Count(t => t.Passed)}/{tests.Count}", string.Join(Environment.NewLine, tests.Select(t => $"[{(t.Passed ? "ĐẠT" : "LỖI")}] {t.Name}: {t.Detail}"))); });
        return p;
    }
}
