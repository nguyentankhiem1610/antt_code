# Bộ công cụ ôn thi mật mã

Ứng dụng Windows Forms và Console trên .NET 8 hỗ trợ ôn tập và tra cứu nhanh các chủ đề An toàn thông tin. Dữ liệu được nhập trực tiếp trong chương trình.

## Chạy chương trình

1. Mở `CryptoExamToolkit.sln` bằng Visual Studio 2022.
2. Nhấp phải `CryptoExam.WinForms` → **Set as Startup Project** để mở giao diện (hoặc chọn `CryptoExam.Console` để dùng menu cũ).
3. Nhấn **Ctrl+F5** để chạy.
4. Trong giao diện, mở tab **Tự kiểm tra / Hướng dẫn** → **Chạy tự kiểm tra**.

Chạy từ terminal:

```powershell
dotnet run --project CryptoExam.Console
dotnet run --project CryptoExam.SelfTest
```

## Quy ước nhập liệu

- Hex chấp nhận chữ hoa/thường, tiền tố `0x` và khoảng trắng, ví dụ `0x1334 5779 9bbc dff1`.
- Danh sách số RSA chấp nhận dấu phẩy hoặc khoảng trắng, ví dụ `64,112,97` hoặc `64 112 97`.
- Mật mã cổ điển tự chuyển chữ thường thành chữ hoa.
- One-Time Pad không lặp khóa; khóa phải có cùng số chữ cái với bản tin.
- DES xử lý khối hex cần 16 ký tự; khóa vòng K_i cần 12 ký tự và R cần 8 ký tự.

## Tra cứu nhanh

| Nội dung | Đường dẫn menu |
|---|---|
| Khóa vòng DES K4 | `2 → 6 → 7. K_i → vòng 4` |
| C3, D3, C3D3 của DES | `2 → 6 → mục 4 / 5 / 6 → vòng 3` |
| IP(M), L0, R0 | `2 → 6 → mục 8 / 9 / 10` |
| E(R0), XOR, S-box, P vòng 1 | `2 → 6 → mục 11 / 12 / 13 / 14 → vòng 1` |
| Dấu vết đầy đủ vòng DES 7 | `2 → 8 → vòng 7` |
| Mã hóa/giải mã DES đầy đủ | `2 → 4 / 5` |
| Chi tiết S-box từ R và K_i | `2 → 3` |
| Dò toàn bộ khóa Caesar | `1 → 1 → 3` |
| Giải mã Vigenère | `1 → 3 → 2` |
| Ma trận và cặp ký tự Playfair | `1 → 5 → 1 / 5 / 6` |
| Hoán vị Rail Fence | `1 → 6` |
| Hoán vị cột / hoán vị kép | `1 → 7 / 8` |
| Nghịch đảo 550 modulo 1759 | `5 → 2` |
| Các bước Euclid | `5 → 3` |
| Tính a^b mod n | `5 → 4 / 5` |
| Tính n, φ, d trong RSA | `4 → 1` |
| Ký RSA theo slide UEH | `4 → 4` |
| Ký/xác thực danh sách RSA | `4 → 9` |
| Mã hóa/giải mã/ký/xác thực RSA chuẩn | `4 → 2 / 3 / 6 / 7` |
| Quy trình RSA đầy đủ | `4 → 8` |
| Trạng thái trung gian AES-128 | `3 → 4` |
| Mã hóa/giải mã AES-192/256 nhanh | `3 → 1 / 2` |
| Double DES / Triple DES EDE / EEE | `6 → chọn chế độ tương ứng` |
| Chuyển đổi, máy tính, tiện ích thi | `8` |

## Quy ước chữ ký RSA

- **UEH / theo slide:** `eA` là khóa bí mật dùng để ký; `dA` là khóa công khai dùng để xác thực. Công thức: `S=M^eA mod n`, `M'=S^dA mod n`.
- **Chế độ chuẩn:** khóa công khai `(e,n)`, khóa bí mật `(d,n)`. Mã hóa `M^e`, giải mã `C^d`, ký `M^d`, xác thực `S^e`.

## Vectơ kiểm tra

- DES `K=133457799BBCDFF1`, `P=0123456789ABCDEF` → `85E813540F0AB405`.
- AES-128 FIPS `P=00112233445566778899AABBCCDDEEFF`, `K=000102030405060708090A0B0C0D0E0F` → `69C4E0D86A7B0430D8CDB78070B4C55A`.
- Playfair `BALLOON`, khóa `MONARCHY` → `IBSUPMNA`.
- RSA UEH `p=13`, `q=17`, `eA=7`, `dA=55`: `64 → 38 → 64`.

## Giao diện Windows Forms mới

Yêu cầu: Windows, Visual Studio có workload **.NET desktop development**, .NET 8 SDK phiên bản 8.0.402 trở lên trong nhánh 8.0.

- **Mã cổ điển:** Caesar, thay thế đơn, Vigenère, Playfair, OTP, Rail Fence, hoán vị cột/kép/ma trận; mã hóa và giải mã.
- **DES / Triple DES:** khối hex, DES đủ 16 vòng, C/D/CD/K, E/XOR/S-box/P; Double DES và Triple DES EDE/EEE.
- **AES:** mã hóa/giải mã AES-128/192/256; các trạng thái vòng khi mã hóa AES-128.
- **RSA:** tính n/φ/d, mã hóa/giải mã danh sách số, ký và khôi phục chữ ký theo chuẩn hoặc quy ước UEH. Đối chiếu số khôi phục với bản tin gốc để xác thực.
- **Máy tính:** cộng/trừ/nhân, chia nguyên và dư, modulo, nhân modulo, lũy thừa modulo, Euclid, nghịch đảo, nguyên tố, đổi cơ số, A0Z25, ASCII, hex/nhị phân, công thức khóa theo ngày/tháng.
- **Thao tác:** dữ liệu mẫu, chuyển kết quả vào đầu vào, sao chép, lưu lời giải UTF-8, xóa; thông báo lỗi nhập liệu.

Giao diện được tạo bằng C# trong `MainForm.cs` và `WorkbenchPage.cs`; chỉnh bố cục tại các file này. Không có file Designer kéo thả. Các chức năng Console chuyên sâu vẫn dùng trong dự án Console.

### Chạy giao diện bằng lệnh

```powershell
dotnet run --project CryptoExam.WinForms
```

### Kiểm tra khi mở trên Windows

1. Build Solution (Ctrl+Shift+B).
2. Chạy tự kiểm tra trong tab hướng dẫn.
3. DES dữ liệu mẫu → Mã hóa: `85E813540F0AB405`; chuyển kết quả vào đầu vào → Giải mã: `0123456789ABCDEF`.
4. AES-128 dữ liệu mẫu → Mã hóa: `69C4E0D86A7B0430D8CDB78070B4C55A`; giải mã trả bản rõ ban đầu.
5. RSA chuẩn dữ liệu mẫu → Mã hóa: `38 5 7`; giải mã trả `64 112 97`.
6. Máy tính mẫu `64^7 mod 221`: `38`; nghịch đảo `550 mod 1759`: `355`.

Giới hạn giao diện: 10000 ký tự đầu vào, 1000 hàng/cột hoán vị, p/q và kiểm tra nguyên tố đến 10^9 để tránh phép thử chia kéo dài. Đây là công cụ bài tập; DES/AES dùng khối đơn, RSA dùng phép tính số theo bài học.
